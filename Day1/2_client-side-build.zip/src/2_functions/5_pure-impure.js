var a = [10, 20, 30];

// Create a function, which can append item to an array

// Impure
// function append(dataArr, item) {
//     dataArr[dataArr.length] = item;
//     return dataArr;
// }

// function append(dataArr, item) {
//     dataArr.push(item);
//     return dataArr;
// }

// Pure
// function append(dataArr, item) {
//     let rArr = [...dataArr];
//     rArr[rArr.length] = item;
//     return rArr;
// }

// function append(dataArr, item) {
//     let rArr = [...dataArr];
//     rArr.push(item);
//     return rArr;
// }

// function append(dataArr, item) {
//     return [...dataArr, item];
// }

// var newArr1 = append(a, 40);
// console.log(newArr1);               // Expected - [10, 20, 30, 40]

// var newArr2 = append(a, 40);
// console.log(newArr2);               // Expected - [10, 20, 30, 40]