'use strict'

// let a = 10;
// console.log("a is: ", a);

// let b;
// b = 20;
// console.log("b is: ", b);

// function test() {
//     let a = 100;                // Local
//     console.log("Inside test(), a is: ", a);
// }

// test();
// console.log("Outside test(), a is: ", a);

// ------------------------------------- Not Hoisted
// a = 10;
// console.log("a is: ", a);
// let a;

// ------------------------------------- Not TypeSafe (Dynamic)
// let a = 10;
// console.log("a is: ", a);
// console.log("Type of, a is: ", typeof a);

// a = "Manish";
// console.log("a is: ", a);
// console.log("Type of, a is: ", typeof a);

// ------------------------------------------------------
// You cannot create a variable with same name in the same scope using let keyword

// let a = 10;
// let a = "Manish";                // Error: Identifier 'a' has already been declared.
// console.log("a is: ", a);
// console.log("Type of, a is: ", typeof a);

// ------------------------------------------------------
// ECMASCRIPT 2015, with let keyword we get
// Global Scope
// Function (Local) Scope
// Block Scope

// var a = 10;

// function test() {
//     if (true) {
//         let a = 100;                // Block Scoped Variable
//         console.log("Inside block(), a is:", a);
//     }
//     console.log("Inside test(), a is: ", a);
// }

// test();
// console.log("Outside test(), a is:", a);

// ----------------------------------

var i = "Hello";
console.log("Before, i:", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside Loop, i:", i);
}

console.log("After, i:", i);
