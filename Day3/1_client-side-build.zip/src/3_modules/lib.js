// Case 1 - Default Export
// export default function square(x) {
//     return x * x;
// }

// Case 2 - Named Export
// export function square(x) {
//     return x * x;
// }

// Case 3 - Multiple Exports
// Only one default export allowed per module.
// export default function square(x) {
//     return x * x;
// }

// export function check(x) {
//     return `Checked: ${x}`;
// }

// export function test(x) {
//     return `Tested: ${x}`;
// }

// --------------------------------------------------
// Create a Person Class with name as data property and create accessor property in lib file

export default class Person {
    constructor(name) {
        this._name = name;
    }

    get Name() {
        return this._name;
    }

    set Name(value) {
        this._name = value;
    }
}