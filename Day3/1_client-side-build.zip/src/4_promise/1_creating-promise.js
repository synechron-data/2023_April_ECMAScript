// function pushData(cb) {
//     setTimeout(function () {
//         cb(1000);
//     }, 5000)
// }

// pushData((data) => {
//     console.log("Result: ", data);
// });

// asyncFunc1(1, ()=>{
//     asyncFunc2(2, ()=>{
//         asyncFunc3(3, ()=>{
//             asyncFunc2(4, ()=>{

//             })
//         })    
//     })
// });

// Testing Becomes Difficult on Functions which accept Callback
// Callback Hell
// Callback Inside Callback, will only be Handled Synchronously

// To resolve these problem areas, we have promise, asyn await, observables

function getData() {
    var promise = new Promise((resolve, reject) => {
        // Async Code
        setTimeout(function () {
            resolve("Hello Synechron");
            // reject("Some Error");
        }, 5000);
    });
    return promise;
}

var promise = getData();

// promise.then((msg) => {
//     console.log("Success: ", msg);
// }, (eMsg) => {
//     console.error("Error: ", eMsg);
// });

// promise.then((msg) => {
//     console.log("Success: ", msg);
// }).catch((eMsg) => {
//     console.error("Error: ", eMsg);
// });

// ECMASCRIPT 2018 - Promise finally
promise.then((msg) => {
    console.log("Success: ", msg);
}).catch((eMsg) => {
    console.error("Error: ", eMsg);
}).finally(()=>{
    console.warn("Finally will always run");
});