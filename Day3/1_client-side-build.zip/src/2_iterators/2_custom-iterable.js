// class Queue {
//     constructor() {
//         this._dataArray = [];
//     }

//     push(data) {
//         this._dataArray.push(data);
//     }

//     pop() {
//         return this._dataArray.shift();
//     }

//     [Symbol.iterator]() {
//         let i = 0;
//         const self = this;

//         return {
//             next: function () {
//                 let v, d = true;

//                 if (self._dataArray[i] !== undefined) {
//                     v = self._dataArray[i];
//                     d = false;
//                     i += 1;
//                 }

//                 return {
//                     value: v,
//                     done: d
//                 };
//             }
//         };
//     }
// }

// let ordersQueue = new Queue();
// ordersQueue.push("Order Id: 1");
// ordersQueue.push("Order Id: 2");
// ordersQueue.push("Order Id: 3");

// // console.log(ordersQueue.pop());
// // console.log(ordersQueue.pop());
// // console.log(ordersQueue.pop());

// for (const order of ordersQueue) {
//     console.log(order);
// }

// ------------------------------------------------------------------
// Assignment - Create a Fibonacci Class to generate Fibonacci Series for given number of items

class Fibonacci {
    constructor(noOfItems) {
        this._noOfItems = noOfItems;
    }

    [Symbol.iterator]() {
        let i = 0
        const self = this;
        let a = 0, b = 1;

        return {
            next: function () {
                if (i < self._noOfItems) {
                    let current = a;
                    a = b;
                    b = current + a;
                    i += 1;

                    return {
                        value: current,
                        done: false
                    };
                } else {
                    return {
                        done: true
                    }
                }
            }
        };
    }
}

let fibObject = new Fibonacci(10);

// for (const i of fibObject) {
//     console.log(i);
// }

let series = [...fibObject];
console.log(series);