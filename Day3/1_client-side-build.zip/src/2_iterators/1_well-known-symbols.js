// let nameSymbol = Symbol("name");

// let obj = {
//     id:1,
//     [nameSymbol]: "Manish"
// };

// console.log(Object.getOwnPropertyNames(obj));
// console.log(Object.getOwnPropertySymbols(obj));

// var arr = new Array();
// console.log(Object.getOwnPropertyNames(arr));
// console.log(Object.getOwnPropertySymbols(arr));
// console.log(Object.getOwnPropertySymbols(Array.prototype));
// console.log(Object.getOwnPropertySymbols(Map.prototype));
// console.log(Object.getOwnPropertySymbols(Set.prototype));
// console.log(Object.getOwnPropertySymbols(WeakMap.prototype));

// --------------------------------------------------

class CustomArray extends Array { 
    static get [Symbol.species]() {
        return Array;
    }
}

let arr = new CustomArray(10, 20, 30);
console.log(arr);

let transformedArray = arr.map(n => n * 100);
console.log(transformedArray);

console.log(arr instanceof CustomArray);
console.log(transformedArray instanceof CustomArray);
console.log(transformedArray instanceof Array);
