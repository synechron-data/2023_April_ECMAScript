// Import an entire module, for side effects only, without importing anything from the file.
// This will run the module's global code, but doesn't import any values.

// import './1_collections/1_es6-map';
// import './1_collections/2_es6-set';

// import './2_iterators/1_well-known-symbols';
// import './2_iterators/2_custom-iterable';
// import './2_iterators/3_generators';

// import './3_modules/usage';

// import './4_promise/1_creating-promise';

import './5_ajax/dom-handler';