import postApiAssignmentClient from "./assignment";
import postApiClient from "./post-api-client";

var ajaxDiv = document.getElementById("ajaxDiv");
var messageDiv = document.getElementById("messageDiv");

if (ajaxDiv.style.display === "none") {
    ajaxDiv.style.display = "block";
    messageDiv.style.display = "none";
}

var button = document.createElement("button");
button.className = "btn btn-primary";
button.innerHTML = "Get Data";

var btnArea = document.getElementById("btnArea");
btnArea.appendChild(button);

// 1. Hard Coded Data
// button.addEventListener("click", function () {
//     // alert("Button was clicked.....");

//     var data = [
//         {
//             userId: 1,
//             id: 1,
//             title: "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
//             body: "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architect"
//         },
//         {
//             userId: 1,
//             id: 2,
//             title: "qui est esse",
//             body: "est rerum tempore vitae\nsequi sint nihil reprehenderit dolor beatae ea dolores neque\nfugiat blanditiis voluptate porro vel nihil molestiae ut reiciendis\nqui aperiam non debitis possimus qui neque nisi"
//         }
//     ];

//     generateTable(data);
// });

// // 2. Api Call Using Callbacks
// button.addEventListener("click", function () {
//     postApiClient.getAllPostsUsingCallbacks((result) => {
//         generateTable(result);
//     }, (eMsg) => {
//         console.error(eMsg);
//     });
// });

// // 3. Api Call Using Promise
// button.addEventListener("click", function () {
//     postApiClient.getAllPostsUsingPromise().then((result) => {
//         generateTable(result);
//     }).catch((eMsg) => {
//         console.error(eMsg);
//     });
// });

// // 3. Using Async Await - ES 2017
// button.addEventListener("click", async function () {
//     try {
//         var result = await postApiClient.getAllPostsUsingPromise();
//         generateTable(result);
//     } catch (eMsg) {
//         console.error(eMsg);
//     }
// });

// // 4. Using Async Function
// button.addEventListener("click", async function () {
//     try {
//         var result = await postApiClient.getAllPostsAsync();
//         generateTable(result);
//     } catch (eMsg) {
//         console.error(eMsg);
//     }
// });

// // 5. Using Async Await with Generator Function
// button.addEventListener("click", async function () {
//     const it = postApiClient.getAllPosts();

//     try {
//         var result = await it.next();
//         generateTable(result.value);
//     } catch (eMsg) {
//         console.error(eMsg);
//     }
// });

// 6. Using Assignment Client
button.addEventListener("click", async function () {
    const gen = postApiAssignmentClient.fetchPosts([10, 20, 3, 4, 5]);
    let data = [];

    // 2018 features - Async Iterators & Generators
    for await (const postData of gen) {
        data = [...data, postData];
    }

    // console.log(data);
    generateTable(data);
});

function generateTable(data) {
    let table = document.getElementById("postTable");
    let row, cell;

    for (const item of data) {
        row = table.insertRow();
        cell = row.insertCell();
        cell.textContent = item.id;
        cell = row.insertCell();
        cell.textContent = item.title;
        cell = row.insertCell();
        cell.textContent = item.body;
    }
}