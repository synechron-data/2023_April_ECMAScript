const url = "https://jsonplaceholder.typicode.com/posts";


const postApiAssignmentClient = {
    fetchPosts: async function* (posts) {
        for (let i = 0; i < posts.length; i++) {
            const postId = posts[i];
            const response = await fetch(`${url}/${postId}`);
            const data = await response.json();
            yield data;            
        }
    }
};

export default postApiAssignmentClient;