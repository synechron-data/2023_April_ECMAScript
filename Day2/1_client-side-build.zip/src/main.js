// Import an entire module, for side effects only, without importing anything from the file.
// This will run the module's global code, but doesn't import any values.

// import './1_functions/1_assignments';
// import './1_functions/2_using_callbacks';
// import './1_functions/3_closures';
// import './1_functions/4_fn_context';
// import './1_functions/5_fn_currying';
// import './1_functions/6_hof';

// import './2_objects/1_object-creation';
// import './2_objects/2_symbol-as-keys';
// import './2_objects/3_object-type';
// import './2_objects/4_object-methods';
// import './2_objects/5_custom-type';
// import './2_objects/6_using-prototype';
// import './2_objects/7_es6-class';
// import './2_objects/8_compare';
// import './2_objects/9_es5-properties';
// import './2_objects/10_es6-properties';
// import './2_objects/11_es5-static-members';
// import './2_objects/12_es6-static-members';
// import './2_objects/13_es5-inheritance';
// import './2_objects/14_es6-inheritance';
// import './2_objects/15_mixins';

import './3_collections/1_arrays';