class Control {
    focus() {
        return "The Control is in Focus";
    }
}

class Selectable {
    select() {
        return "The Control is Selected";
    }
}

function applyMixins(derivedCtor, constructors) {
    constructors.forEach(function (baseCtor) {
        Object.getOwnPropertyNames(baseCtor.prototype).forEach(function (name) {
            Object.defineProperty(derivedCtor.prototype, name,
                Object.getOwnPropertyDescriptor(baseCtor.prototype, name) || Object.create(null));
        });
    });
}

class Button {

}

applyMixins(Button, [Control, Selectable]);

let button = new Button();
console.log(button.focus());
console.log(button.select());