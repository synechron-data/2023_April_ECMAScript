class Person {
    constructor(name, age = 0) {
        this._name = name;
        this._age = age;
    }

    get Name() {
        return this._name;
    }

    set Name(value) {
        this._name = value;
    }

    get Age() {
        return this._age;
    }

    set Age(value) {
        this._age = value;
    }
}

var p1 = new Person("Manish", 0);
console.log(p1.Name);           // get
console.log(p1.Age);            // get
p1.Name = "Abhijeet";           // set
p1.Age = 39;                    // set
console.log(p1.Name);           // get
console.log(p1.Age);            // get