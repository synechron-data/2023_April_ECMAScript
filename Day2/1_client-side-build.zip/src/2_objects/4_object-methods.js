// ---------------------------------------------------- Object.assign (Shallow Copy)

// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// let assignedObj = Object.assign({}, source);

// assignedObj.name = "Abhijeet";
// assignedObj.address.city = "Mumbai";

// console.log(source);
// console.log(assignedObj);

// ---------------------------------------------------- Object.create
// Creates a new object, using an existing object as the prototype of the newly created object.

// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// let assignedObj = Object.assign({}, source);
// let createdObj = Object.create(source);

// console.log("Source: ", source);
// console.log("Assign: ", assignedObj);
// console.log("Create: ", createdObj);

// ----------------------------------------------------

let source = { id: 1, name: "Manish" };

// // Add a New Property
// source.city = "Pune";
// console.log(source);

// // Delete a Property
// delete source.name;
// console.log(source);

// // Modify the Property Value
// source.id = 1000;
// console.log(source);

// // -------------------------------------
// // Add a New Property           - Not Allowed
// // Delete a Property            - Allowed
// // Modify the Property Value    - Allowed

// Object.preventExtensions(source);

// if(Object.isExtensible(source)) {
//     source.city = "Pune";
//     console.log(source);
// } else {
//     console.warn("Source Object is not Extensible");
// }

// delete source.name;
// console.log(source);

// source.id = 1000;
// console.log(source);

// // -------------------------------------
// // Add a New Property           - Not Allowed
// // Delete a Property            - Not Allowed
// // Modify the Property Value    - Allowed

// Object.seal(source);

// if (!Object.isSealed(source)) {
//     source.city = "Pune";
//     console.log(source);

//     delete source.name;
//     console.log(source);
// } else {
//     console.warn("You cannot add or delete property from the Source Object");
// }

// source.id = 1000;
// console.log(source);

// -------------------------------------
// Add a New Property           - Not Allowed
// Delete a Property            - Not Allowed
// Modify the Property Value    - Not Allowed

Object.freeze(source);

if (!Object.isFrozen(source)) {
    source.city = "Pune";
    console.log(source);

    delete source.name;
    console.log(source);

    source.id = 1000;
    console.log(source);
} else {
    console.warn("You cannot add, delete or modify property in the Source Object");
}