// var person = {
//     id: 1,
//     name: "Manish",
//     username: "ManishS",
//     password: "ManishS",
//     address: {
//         state: "MH",
//         pin: 411021
//     }
// };

// console.log(person);
// const person_JSON = JSON.stringify(person);
// console.log(person_JSON);

// ---------------------------------------------
// var person = {
//     id: 1,
//     name: "Manish",
//     [Symbol("username")]: "ManishS",
//     [Symbol("password")]: "ManishS",
//     address: {
//         state: "MH",
//         pin: 411021
//     }
// };

// console.log(person);
// console.log(person[Symbol("username")]);
// console.log(person[Symbol("password")]);

// const person_JSON = JSON.stringify(person);
// console.log(person_JSON);

// ---------------------------------------------
const username = Symbol("username");
const password = Symbol("password");

var person = {
    id: 1,
    name: "Manish",
    [username]: "ManishS",
    [password]: "ManishSS",
    address: {
        state: "MH",
        pin: 411021
    }
};

console.log(person);
console.log(person[username]);
console.log(person[password]);

const person_JSON = JSON.stringify(person);
console.log(person_JSON);