'use strict'

// // In ES ‘this’ refers to the parent of the function and the object through which the function was called
// function test1() {
//     console.log(this);
// }

// test1();

// const test2 = function () {
//     console.log(this);
// }

// test2();

// var p1 = {
//     id: 1,
//     test: function () {
//         console.log(this);
//     }
// };

// p1.test();

// --------------------
// console.log("Context of the file:", this);
// var self = this;

// // In ES6, arrow functions use lexical scoping — ‘this’ refers to it’s current surrounding scope and no further.
// const test3 = () => {
//     console.log(this);
//     console.log(self === this);
// };

// test3();

// -------------------------------------------------------------- Switching Context
// var p1 = {
//     id: 1
// }

// // function check(x, y) {
// //     console.log(x, y);
// //     console.log(this);
// // }

// // const check = function (x, y) {
// //     console.log(x, y);
// //     console.log(this);
// // }

// // In ES6, arrow functions use lexical scoping — ‘this’ refers to it’s current surrounding scope and no further.
// // Context of an arrow function is fixed
// const check = (x, y) => {
//     console.log(x, y);
//     console.log(this);
// }

// check(2, 3);
// // setTimeout(check, 1000);
// check.call(p1, 20, 30);
// check.apply(p1, [21, 31]);

// const bindedToP1 = check.bind(p1);
// bindedToP1(22, 33);

// -------------------------------------------------- Function Borrowing
// var p1 = {
//     id: 1,
//     name: "Manish",
//     toJson: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// var p2 = {
//     id: 2,
//     name: "Abhijeet",
//     toJson: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// p1.toJson();
// p2.toJson();

// ------------------
// const toJson = function () {
//     console.log(JSON.stringify(this));
// }

// var p1 = {
//     id: 1,
//     name: "Manish"
// };

// var p2 = {
//     id: 2,
//     name: "Abhijeet"
// };

// // toJson.call(p1);
// // toJson.call(p2);

// p1.toJson = toJson.bind(p1);
// p2.toJson = toJson.bind(p2);

// p1.toJson();
// p2.toJson();

// ------------------------

// var p1 = {
//     id: 1,
//     name: "Manish",
//     toJson: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// var p2 = {
//     id: 2,
//     name: "Abhijeet"
// };

// p2.toJson = p1.toJson.bind(p2);

// p1.toJson();
// p2.toJson();

// ------------------------------------------------------------------------

var person = {
    age: 0,
    growOld: function () {
        console.log("growOld executed, under context of:", this);
        this.age += 1;
    }
};

// console.log(person.age);

// person.growOld();
// console.log(person.age);

// person.growOld();
// console.log(person.age);

// person.growOld();
// console.log(person.age);

// // ---------------------------------------------------- Problem
// // In ES ‘this’ refers to the parent of the function and the object through which the function was called (invoked)

// var btn = document.createElement("button");
// btn.className = "btn btn-primary btn-block";
// btn.innerHTML = "Click";

// var btnArea = document.getElementById("btnArea");
// btnArea.appendChild(btn);

// btn.addEventListener("click", person.growOld);
// setInterval(person.growOld, 2000);

// ---------------------------------------------------- Solution
// In ES ‘this’ refers to the parent of the function and the object through which the function was called (invoked)

var btn = document.createElement("button");
btn.className = "btn btn-primary btn-block";
btn.innerHTML = "Click";

var btnArea = document.getElementById("btnArea");
btnArea.appendChild(btn);

btn.addEventListener("click", person.growOld.bind(person));
setInterval(person.growOld.bind(person), 2000);