// -------------------------------------------------- Pull

// // Dev 1 - Sync
// function getString() {
//     const strArr = ["NodeJS", "ReactJS", "Angular", "ExtJS", "jQuery"];
//     var str = strArr[Math.floor(Math.random() * strArr.length)];
//     return str;
// }

// // Dev 2
// // var s = getString();
// // console.log(s);

// setInterval(() => {
//     var s = getString();
//     console.log(s);
// }, 2000);

// -------------------------------------------------- Push

// // Dev 1 - Async Code
// function pushString(cb) {
//     const strArr = ["NodeJS", "ReactJS", "Angular", "ExtJS", "jQuery"];
//     // Async Code
//     setInterval(() => {
//         var str = strArr[Math.floor(Math.random() * strArr.length)];
//         cb(str);
//     }, 2000);
// }

// // Dev 2
// pushString(function (s) {
//     console.log("C1 - ", s);
// });

// pushString(function (s) {
//     console.log("C2 - ", s);
// });

// -------------------------------------------------- XHR

// var xhr = new XMLHttpRequest();

// xhr.open('GET', 'https://ajsonplaceholder.typicode.com/posts');

// xhr.responseType = 'json';

// xhr.onload = function () {
//     if (xhr.status === 200) {
//         var responseData = xhr.response;
//         console.log(responseData);
//     }
// }

// xhr.onerror = function () {
//     console.error('An error occurred while making the request.');
// }

// xhr.send();

// Convert the code into a function

// Dev 1
function getPosts(successCB, errorCB) {
    var xhr = new XMLHttpRequest();

    xhr.open('GET', 'https://jsonplaceholder.typicode.com/posts');

    xhr.responseType = 'json';

    xhr.onload = function () {
        if (xhr.status === 200) {
            var responseData = xhr.response;
            successCB(responseData);
        }
    }

    xhr.onerror = function () {
        errorCB('An error occurred while making the request.');
    }

    xhr.send();
}

// Dev 2
getPosts((result) => {
    console.log(result);
}, (eMsg) => {
    console.error(eMsg);
});