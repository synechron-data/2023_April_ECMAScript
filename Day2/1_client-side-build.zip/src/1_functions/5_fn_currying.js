// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// greetings("Good Morning", "Dimple");
// greetings("Good Morning", "Sanjana");
// greetings("Good Morning", "Manoj");

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// console.log(Converter(" INR", 82.19, 0, 100));
// console.log(Converter(" INR", 82.19, 0, 299));
// console.log(Converter(" INR", 82.19, 0, 765));
// console.log(Converter(" INR", 82.19, 0, 999));

// -----------------------------------------------------------

// function greetings(message) {
//     return function (name) {
//         console.log(`${message}, ${name}`);
//     }
// }

// const mGreet = greetings("Good Morning");

// mGreet("Dimple");
// mGreet("Sanjana");
// mGreet("Manoj");

// const aGreet = greetings("Good Afternoon");

// aGreet("Dimple");
// aGreet("Sanjana");
// aGreet("Manoj");

// const tGreet = greetings("Thank you");

// tGreet("Dimple");
// tGreet("Sanjana");
// tGreet("Manoj");

// function Converter(toUnit, factor, offset) {
//     return function (input) {
//         return [((offset + input) * factor).toFixed(2), toUnit].join("");
//     }
// }

// const usdToInrConverter = Converter(" INR", 82.19, 0);
// console.log(usdToInrConverter(100));
// console.log(usdToInrConverter(299));
// console.log(usdToInrConverter(765));
// console.log(usdToInrConverter(999));

// console.log("\n");
// const milesToKmConverter = Converter(" KM", 1.60934, 0);
// console.log(milesToKmConverter(100));
// console.log(milesToKmConverter(299));
// console.log(milesToKmConverter(765));
// console.log(milesToKmConverter(999));

// -----------------------------------------------------------

function greetings(message, name) {
    console.log(`${message}, ${name}`);
}

const mGreet = greetings.bind(undefined, "Good Morning");

mGreet("Dimple");
mGreet("Sanjana");
mGreet("Manoj");

function Converter(toUnit, factor, offset, input) {
    return [((offset + input) * factor).toFixed(2), toUnit].join("");
}

const usdToInrConverter = Converter.bind(undefined, " INR", 82.19, 0);
console.log(usdToInrConverter(100));
console.log(usdToInrConverter(299));
console.log(usdToInrConverter(765));
console.log(usdToInrConverter(999));